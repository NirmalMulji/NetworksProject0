Nirmal Mulji
npm435

writeup:

ex0:

log information:
    skipper.cs.utexas.edu
    Client -> Server: ex0 128.83.144.56-35601 128.83.139.132-38642 1437 N.P.MULJI
    Server -> Client: CS 356 Server Fri Oct 06 18:16:34 CDT 2017
    Server -> Client: OK 1438 N.P.MULJI 627078
    Client -> Server: ex0 1438 627079
    Server -> Client: CS 356 Server Fri Oct 06 18:16:34 CDT 2017 OK 627079

information client received from server:
first server conformation:
    CS 356 Server Fri Oct 06 18:16:34 CDT 2017
    OK 1438 N.P.MULJI 627078
second server conformation:
    CS 356 Server Fri Oct 06 18:16:34 CDT 2017 OK 627079


ex1:

log information:
    skipper.cs.utexas.edu
    Client -> Server: ex1 128.83.144.56-35601 128.83.139.132-39113 8464 N.P.MULJI
    Server -> Client: CS 356 Server Fri Oct 06 22:47:02 CDT 2017
    Server -> Client: OK 8465 N.P.MULJI 3295433
    Server -> Client: Connected to a client(128.83.139.132-39113)
    Server -> Client: CS 356 server calling 5813247
    Client -> Server(servernum+1 newservernum+1): 3295434 5813248
    Server -> Client: OK	8875907

information client received from servers:
    psock address: 128.83.139.132
    psock port:  39113

    CS 356 Server Fri Oct 06 22:47:02 CDT 2017
    OK 8465 N.P.MULJI 3295433

    CS 356 server calling 5813247
    CS 356 server sent 5813247
    OK      8875907



